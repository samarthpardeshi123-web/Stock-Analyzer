import streamlit as st
import pandas as pd
import plotly.graph_objects as go

from utils.data_fetcher import get_stock_data, nifty50
from utils.feature_engineering import add_features
from utils.model_trainer import train_models, predict_price
from utils.chatbot_logic import chatbot_response
from utils.news_sentiment import get_sentiment
from utils.graph import plot_advanced_chart

# ──────────────────────────────────────────────
# PAGE CONFIG
# ──────────────────────────────────────────────
st.set_page_config(
    page_title="AI Stock Analyser",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ──────────────────────────────────────────────
# HIDE MAIN PAGE FROM SIDEBAR NAV
# ──────────────────────────────────────────────
st.markdown("""
<style>
    [data-testid="stSidebarNav"] { display: none; }
</style>
""", unsafe_allow_html=True)

# ──────────────────────────────────────────────
# CUSTOM CSS
# ──────────────────────────────────────────────
st.markdown("""
<style>
    .news-card { background:#0f1c2b; border-left:3px solid #2196f3; border-radius:6px; padding:10px 14px; margin:6px 0; font-size:14px; }
    .section-title { font-size:18px; font-weight:700; color:#90caf9; margin:20px 0 10px; border-bottom:1px solid #1e3a5f; padding-bottom:6px; }
    div[data-testid="stChatMessage"] { background:#0d2137; border-radius:10px; padding:10px; margin:4px 0; }
</style>
""", unsafe_allow_html=True)

# ──────────────────────────────────────────────
# SIDEBAR
# ──────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 📈 AI Stock Analyser")
    st.markdown("*NIFTY 50 · Prediction + Sentiment*")
    st.divider()

    st.page_link("pages/1_Compare_Stocks.py", label="🔀 Compare Stocks")

    st.divider()

    stock = st.selectbox("🔍 Select Stock", list(nifty50.keys()),
                         format_func=lambda x: f"{nifty50[x]} ({x})")

    period = st.selectbox("📅 Data Period", ["6mo", "1y", "2y"], index=1)

    st.divider()
    st.markdown("**About**")
    st.markdown(
        "Uses **Random Forest**, **Gradient Boosting**, and **Linear Regression** "
        "with RSI, MACD, Bollinger Bands and news sentiment."
    )
    st.markdown("⚠️ *Educational project only.*")

# ──────────────────────────────────────────────
# LOAD & PROCESS DATA
# ──────────────────────────────────────────────
@st.cache_data(ttl=600, show_spinner=False)
def load_data(ticker, period):
    df = get_stock_data(ticker, period)
    df = add_features(df)
    return df

@st.cache_data(ttl=600, show_spinner=False)
def load_sentiment(ticker):
    return get_sentiment(ticker)

with st.spinner(f"Loading data for {nifty50[stock]}..."):
    data = load_data(stock, period)
    headlines, scores, avg_score, sent_label = load_sentiment(stock)
    models, model_results = train_models(data)
    predictions = predict_price(models, data)

current_price = float(data["Close"].values[-1])
best_model    = max(model_results, key=lambda k: model_results[k]['R²'])
best_pred     = predictions[best_model]
pct_change    = ((best_pred - current_price) / current_price) * 100

# ──────────────────────────────────────────────
# HEADER
# ──────────────────────────────────────────────
st.markdown(f"# 📊 {nifty50[stock]}")
st.markdown(f"`{stock}` &nbsp;|&nbsp; Period: **{period}** &nbsp;|&nbsp; Best Model: **{best_model}**")

# ──────────────────────────────────────────────
# KPI METRIC CARDS
# ──────────────────────────────────────────────
col1, col2, col3, col4, col5 = st.columns(5)

with col1:
    st.metric("💰 Current Price", f"₹{current_price:,.2f}")

with col2:
    st.metric("🎯 Predicted Price", f"₹{best_pred:,.2f}", delta=f"{pct_change:+.2f}%")

with col3:
    rsi_val    = float(data['RSI'].values[-1])
    rsi_status = "Overbought 🔴" if rsi_val > 70 else ("Oversold 🟢" if rsi_val < 30 else "Neutral 🟡")
    st.metric("📉 RSI (14)", f"{rsi_val:.1f}", delta=rsi_status)

with col4:
    st.metric("📰 Sentiment", sent_label, delta=f"Score: {avg_score:+.3f}")

with col5:
    vol_today = float(data['Volume'].values[-1])
    vol_avg   = float(data['Volume_MA'].values[-1])
    vol_ratio = vol_today / vol_avg if vol_avg else 1
    st.metric("📦 Volume Ratio", f"{vol_ratio:.2f}x",
              delta="Above avg" if vol_ratio > 1.2 else "Normal")

st.divider()

# ──────────────────────────────────────────────
# TABS
# ──────────────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs(
    ["📈 Charts & Indicators", "🤖 Model Comparison", "📰 News & Sentiment", "💬 StockBot Chat"]
)

# ─── TAB 1: Charts ────────────────────────────
with tab1:
    st.markdown('<p class="section-title">Interactive Technical Chart</p>', unsafe_allow_html=True)
    plot_advanced_chart(data, nifty50[stock])

    st.markdown('<p class="section-title">Latest Indicator Snapshot</p>', unsafe_allow_html=True)
    c1, c2, c3, c4 = st.columns(4)

    with c1:
        macd_val   = float(data['MACD'].values[-1])
        sig_val    = float(data['MACD_Signal'].values[-1])
        macd_cross = "Bullish ▲" if macd_val > sig_val else "Bearish ▼"
        st.metric("MACD", f"{macd_val:.2f}", delta=macd_cross)

    with c2:
        bb_up  = float(data['BB_Upper'].values[-1])
        bb_low = float(data['BB_Lower'].values[-1])
        bb_pos = ((current_price - bb_low) / (bb_up - bb_low)) * 100 if (bb_up - bb_low) != 0 else 50
        st.metric("BB Position", f"{bb_pos:.0f}%",
                  delta="Near upper band" if bb_pos > 75 else ("Near lower band" if bb_pos < 25 else "Mid band"))

    with c3:
        ma10  = float(data['MA10'].values[-1])
        ma50  = float(data['MA50'].values[-1])
        trend = "Uptrend ▲" if ma10 > ma50 else "Downtrend ▼"
        st.metric("MA10 vs MA50", trend, delta=f"MA10: ₹{ma10:.1f}")

    with c4:
        volatility = float(data['Volatility'].values[-1]) * 100
        st.metric("10-Day Volatility", f"{volatility:.2f}%")

# ─── TAB 2: Model Comparison ──────────────────
with tab2:
    st.markdown('<p class="section-title">Model Performance Comparison</p>', unsafe_allow_html=True)

    rows = []
    for name, m in model_results.items():
        rows.append({
            'Model':           name,
            'RMSE (₹)':        m['RMSE'],
            'MAE (₹)':         m['MAE'],
            'R² Score':        m['R²'],
            'Dir Accuracy':    f"{m['Dir Acc']}%",
            'Predicted Price': f"₹{predictions[name]:,.2f}",
        })
    df_metrics = pd.DataFrame(rows).set_index('Model')
    st.dataframe(df_metrics, use_container_width=True)

    st.markdown('<p class="section-title">RMSE Comparison</p>', unsafe_allow_html=True)
    fig_bar = go.Figure(go.Bar(
        x=list(model_results.keys()),
        y=[m['RMSE'] for m in model_results.values()],
        marker_color=['#2196f3', '#26a69a', '#ff9800'],
        text=[f"₹{m['RMSE']}" for m in model_results.values()],
        textposition='outside',
    ))
    fig_bar.update_layout(
        paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
        yaxis_title='RMSE (₹)', height=300,
        yaxis=dict(gridcolor='rgba(128,128,128,0.15)'),
        margin=dict(t=20, b=20),
    )
    st.plotly_chart(fig_bar, use_container_width=True)

    st.markdown('<p class="section-title">Next-Day Price Predictions</p>', unsafe_allow_html=True)
    pred_cols = st.columns(len(predictions))
    for col, (name, price) in zip(pred_cols, predictions.items()):
        chg = ((price - current_price) / current_price) * 100
        col.metric(name, f"₹{price:,.2f}", delta=f"{chg:+.2f}%")

# ─── TAB 3: News & Sentiment ──────────────────
with tab3:
    st.markdown('<p class="section-title">News Sentiment Analysis</p>', unsafe_allow_html=True)

    col_gauge, col_info = st.columns([1, 1])

    with col_gauge:
        fig_gauge = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=avg_score,
            delta={'reference': 0, 'suffix': ''},
            title={'text': "Sentiment Score", 'font': {'size': 14}},
            gauge={
                'axis': {'range': [-1, 1], 'tickwidth': 1},
                'bar': {'color': "#26a69a" if avg_score > 0 else "#ef5350"},
                'steps': [
                    {'range': [-1,    -0.05], 'color': '#3a1b1b'},
                    {'range': [-0.05,  0.05], 'color': '#2a2a1e'},
                    {'range': [0.05,   1   ], 'color': '#1b3a2f'},
                ],
                'threshold': {
                    'line': {'color': "white", 'width': 2},
                    'thickness': 0.75,
                    'value': avg_score,
                }
            }
        ))
        fig_gauge.update_layout(
            height=250, paper_bgcolor='rgba(0,0,0,0)',
            font=dict(color='white'),
            margin=dict(t=30, b=10, l=20, r=20),
        )
        st.plotly_chart(fig_gauge, use_container_width=True)

    with col_info:
        st.markdown(f"**Overall Sentiment:** {sent_label}")
        st.markdown(f"**VADER Score:** `{avg_score:+.4f}`")
        st.markdown("- Score > 0.05 → **Positive**")
        st.markdown("- Score < -0.05 → **Negative**")
        st.markdown("- Between → **Neutral**")
        st.markdown("*Analysed using VADER (Valence Aware Dictionary and sEntiment Reasoner)*")

    st.markdown('<p class="section-title">Recent News Headlines</p>', unsafe_allow_html=True)
    if headlines:
        for headline, score in zip(headlines, scores):
            badge = "🟢 Positive" if score > 0.05 else ("🔴 Negative" if score < -0.05 else "🟡 Neutral")
            st.markdown(
                f'<div class="news-card">{headline}<br>'
                f'<small style="color:#7fa8cc">{badge} &nbsp; score: {score:+.3f}</small></div>',
                unsafe_allow_html=True
            )
    else:
        st.info("No recent headlines found for this ticker.")

    if 'Daily_Return' in data.columns:
        st.markdown('<p class="section-title">Daily Return — Last 30 Days</p>', unsafe_allow_html=True)
        daily_ret = data['Daily_Return'].tail(30)
        fig_ret = go.Figure()
        fig_ret.add_trace(go.Bar(
            x=data['Date'].tail(30),
            y=daily_ret * 100,
            marker_color=['#26a69a' if v >= 0 else '#ef5350' for v in daily_ret],
            name='Daily Return %',
        ))
        fig_ret.update_layout(
            paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
            yaxis_title='Daily Return (%)', height=250,
            yaxis=dict(gridcolor='rgba(128,128,128,0.15)'),
            margin=dict(t=10, b=20),
        )
        st.plotly_chart(fig_ret, use_container_width=True)

# ─── TAB 4: Chatbot ───────────────────────────
with tab4:
    st.markdown('<p class="section-title">💬 Ask StockBot</p>', unsafe_allow_html=True)
    st.markdown("Ask about **price**, **buy/sell/hold advice**, **RSI**, **news sentiment**, or **model accuracy**.")

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    for msg in st.session_state.chat_history:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    user_query = st.chat_input("Type your question here...")

    if user_query:
        st.session_state.chat_history.append({"role": "user", "content": user_query})
        with st.chat_message("user"):
            st.markdown(user_query)

        reply = chatbot_response(
            user_query, stock, predictions, current_price,
            model_results, sent_label, float(data['RSI'].values[-1])
        )

        st.session_state.chat_history.append({"role": "assistant", "content": reply})
        with st.chat_message("assistant"):
            st.markdown(reply)

    if st.button("🗑️ Clear Chat"):
        st.session_state.chat_history = []
        st.rerun()

st.caption("⚠️ Educational project only. Not financial advice.")