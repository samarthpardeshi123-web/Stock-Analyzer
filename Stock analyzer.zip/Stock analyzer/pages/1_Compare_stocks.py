import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from utils.data_fetcher import get_stock_data, nifty50
from utils.feature_engineering import add_features
from utils.model_trainer import train_models, predict_price

st.set_page_config(page_title="Compare Stocks", page_icon="🔀", layout="wide")

st.markdown("# 🔀 Compare Two Stocks")
st.markdown("Side-by-side comparison + AI verdict on which stock is better.")
st.divider()

c1, c2, c3 = st.columns([2, 2, 1])
with c1:
    stock_a = st.selectbox("Stock A", list(nifty50.keys()),
                           format_func=lambda x: f"{nifty50[x]} ({x})", index=0)
with c2:
    stock_b = st.selectbox("Stock B", list(nifty50.keys()),
                           format_func=lambda x: f"{nifty50[x]} ({x})", index=1)
with c3:
    period = st.selectbox("Period", ["3mo", "6mo", "1y", "2y"], index=2)

if stock_a == stock_b:
    st.warning("Please select two different stocks.")
    st.stop()

@st.cache_data(ttl=600)
def get_processed(ticker, period):
    df = get_stock_data(ticker, period)
    df = add_features(df)
    return df

with st.spinner("Loading comparison data..."):
    df_a = get_processed(stock_a, period)
    df_b = get_processed(stock_b, period)
    models_a, results_a = train_models(df_a)
    models_b, results_b = train_models(df_b)
    preds_a = predict_price(models_a, df_a)
    preds_b = predict_price(models_b, df_b)

name_a = nifty50[stock_a]
name_b = nifty50[stock_b]

# ── Normalised price chart ──────────────────────────────────────────
st.markdown("### 📊 Normalised Price Performance (base = 100)")
norm_a = (df_a['Close'] / float(df_a['Close'].values[0])) * 100
norm_b = (df_b['Close'] / float(df_b['Close'].values[0])) * 100

fig_norm = go.Figure()
fig_norm.add_trace(go.Scatter(x=df_a['Date'], y=norm_a, name=name_a, line=dict(color='#2196f3', width=2)))
fig_norm.add_trace(go.Scatter(x=df_b['Date'], y=norm_b, name=name_b, line=dict(color='#ff9800', width=2)))
fig_norm.update_layout(
    paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
    yaxis_title='Normalised Price', height=350,
    yaxis=dict(gridcolor='rgba(128,128,128,0.15)'),
    legend=dict(orientation='h'), margin=dict(t=10, b=10),
)
st.plotly_chart(fig_norm, use_container_width=True)

# ── RSI Comparison ──────────────────────────────────────────────────
st.markdown("### 📉 RSI (14) Comparison")
fig_rsi = go.Figure()
fig_rsi.add_trace(go.Scatter(x=df_a['Date'], y=df_a['RSI'], name=name_a, line=dict(color='#2196f3', width=1.5)))
fig_rsi.add_trace(go.Scatter(x=df_b['Date'], y=df_b['RSI'], name=name_b, line=dict(color='#ff9800', width=1.5)))
for level in [70, 30]:
    fig_rsi.add_hline(y=level, line_dash='dash', line_color='rgba(200,200,200,0.3)', line_width=0.8)
fig_rsi.update_layout(
    paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
    yaxis_title='RSI', height=250,
    yaxis=dict(gridcolor='rgba(128,128,128,0.15)', range=[0, 100]),
    legend=dict(orientation='h'), margin=dict(t=10, b=10),
)
st.plotly_chart(fig_rsi, use_container_width=True)

# ── Key Stats Table ─────────────────────────────────────────────────
st.markdown("### 📋 Key Stats Comparison")

def get_stats(df, name, preds, results):
    ret = df['Daily_Return'].dropna()
    best_model = max(results, key=lambda k: results[k]['R²'])
    curr_price = float(df['Close'].values[-1])
    pred_price = preds[best_model]
    pred_chg   = ((pred_price - curr_price) / curr_price) * 100
    one_y_ret  = ((curr_price / float(df['Close'].values[0])) - 1) * 100
    return {
        'Stock':            name,
        'Current Price':    f"₹{curr_price:,.2f}",
        '1Y Return':        f"{one_y_ret:+.1f}%",
        'Latest RSI':       f"{float(df['RSI'].values[-1]):.1f}",
        'Predicted Change': f"{pred_chg:+.2f}%",
        'Best Model R²':    f"{results[best_model]['R²']:.4f}",
        'Volatility':       f"{ret.std()*100:.2f}%",
        'Max Drawdown':     f"{((df['Close'] / df['Close'].cummax()) - 1).min()*100:.1f}%",
        'Avg Daily Return': f"{ret.mean()*100:.3f}%",
    }

stats_a = get_stats(df_a, name_a, preds_a, results_a)
stats_b = get_stats(df_b, name_b, preds_b, results_b)

df_stats = pd.DataFrame([stats_a, stats_b]).set_index('Stock')
st.dataframe(df_stats, use_container_width=True)

# ── AI VERDICT ──────────────────────────────────────────────────────
st.divider()
st.markdown("## 🤖 AI Prediction — Which Stock is Better?")

def score_stock(df, preds, results):
    score = 0
    reasons = []

    curr  = float(df['Close'].values[-1])
    best  = max(results, key=lambda k: results[k]['R²'])
    pred  = preds[best]
    chg   = ((pred - curr) / curr) * 100
    rsi   = float(df['RSI'].values[-1])
    ret   = df['Daily_Return'].dropna()
    one_y = ((curr / float(df['Close'].values[0])) - 1) * 100
    vol   = ret.std() * 100
    macd  = float(df['MACD'].values[-1])
    sig   = float(df['MACD_Signal'].values[-1])
    r2    = results[best]['R²']

    # 1. Predicted price direction
    if chg > 2:
        score += 3
        reasons.append(f"✅ Model predicts **+{chg:.1f}%** price rise tomorrow")
    elif chg > 0:
        score += 1
        reasons.append(f"✅ Model predicts small rise (**+{chg:.1f}%**)")
    else:
        score -= 2
        reasons.append(f"❌ Model predicts price drop (**{chg:.1f}%**)")

    # 2. RSI signal
    if rsi < 35:
        score += 2
        reasons.append(f"✅ RSI **{rsi:.1f}** — oversold, potential bounce zone")
    elif rsi > 65:
        score -= 1
        reasons.append(f"⚠️ RSI **{rsi:.1f}** — overbought, momentum may slow")
    else:
        score += 1
        reasons.append(f"✅ RSI **{rsi:.1f}** — healthy neutral zone")

    # 3. 1Y return
    if one_y > 15:
        score += 2
        reasons.append(f"✅ Strong 1-year return of **{one_y:+.1f}%**")
    elif one_y > 0:
        score += 1
        reasons.append(f"✅ Positive 1-year return (**{one_y:+.1f}%**)")
    else:
        score -= 1
        reasons.append(f"❌ Negative 1-year return (**{one_y:+.1f}%**)")

    # 4. MACD crossover
    if macd > sig:
        score += 1
        reasons.append("✅ MACD above signal line — **bullish crossover**")
    else:
        score -= 1
        reasons.append("⚠️ MACD below signal line — **bearish crossover**")

    # 5. Volatility (lower = safer)
    if vol < 1.5:
        score += 1
        reasons.append(f"✅ Low volatility (**{vol:.2f}%**) — relatively stable")
    elif vol > 2.5:
        score -= 1
        reasons.append(f"⚠️ High volatility (**{vol:.2f}%**) — higher risk")
    else:
        reasons.append(f"➡️ Moderate volatility (**{vol:.2f}%**)")

    # 6. Model confidence
    if r2 > 0.95:
        score += 1
        reasons.append(f"✅ High model confidence (R² = **{r2:.4f}**)")
    else:
        reasons.append(f"➡️ Model R² = **{r2:.4f}**")

    return score, reasons

score_a, reasons_a = score_stock(df_a, preds_a, results_a)
score_b, reasons_b = score_stock(df_b, preds_b, results_b)

col_a, col_vs, col_b = st.columns([5, 1, 5])

with col_a:
    st.markdown(f"#### 🔵 {name_a}")
    st.markdown(f"**Score: {score_a} / 10**")
    st.progress(max(0, min(score_a / 10, 1.0)))
    for r in reasons_a:
        st.markdown(f"- {r}")

with col_vs:
    st.markdown("<br><br><br>", unsafe_allow_html=True)
    st.markdown("### VS")

with col_b:
    st.markdown(f"#### 🟠 {name_b}")
    st.markdown(f"**Score: {score_b} / 10**")
    st.progress(max(0, min(score_b / 10, 1.0)))
    for r in reasons_b:
        st.markdown(f"- {r}")

# Final verdict box
st.divider()
if score_a > score_b:
    winner, loser, ws, ls = name_a, name_b, score_a, score_b
    color = "#1b3a2f"
    border = "#26a69a"
elif score_b > score_a:
    winner, loser, ws, ls = name_b, name_a, score_b, score_a
    color = "#1b3a2f"
    border = "#26a69a"
else:
    winner = None

if winner:
    st.markdown(
        f"""<div style="background:{color};border:1px solid {border};border-radius:12px;padding:20px 24px;">
        <h3 style="color:#4caf7d;margin:0">🏆 AI Prediction: {winner} is the better pick</h3>
        <p style="color:#a0cfb8;margin:8px 0 0">
        {winner} scored <b>{ws}</b> vs {loser}'s <b>{ls}</b> across 6 signals:
        predicted price change, RSI zone, 1-year return, MACD crossover, volatility, and model confidence.
        </p></div>""",
        unsafe_allow_html=True
    )
else:
    st.markdown(
        f"""<div style="background:#2a2a1e;border:1px solid #ff9800;border-radius:12px;padding:20px 24px;">
        <h3 style="color:#ff9800;margin:0">🤝 AI Prediction: Both stocks are equally matched</h3>
        <p style="color:#c8b87a;margin:8px 0 0">
        Both scored equally across all 6 signals. Consider your own risk appetite before choosing.
        </p></div>""",
        unsafe_allow_html=True
    )

st.markdown("<br>", unsafe_allow_html=True)
st.caption("⚠️ Educational project only. Not financial advice.")
