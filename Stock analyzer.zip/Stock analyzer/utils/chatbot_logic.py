def chatbot_response(user_input, ticker, predictions, current_price,
                     model_results, sentiment_label, rsi_value):
    """
    Smart chatbot that uses multiple signals to give advice.
    """
    txt = user_input.lower().strip()

    # ── Price / Prediction ───────────────────────────────────────────
    if any(w in txt for w in ['price', 'predict', 'forecast', 'tomorrow']):
        lines = [f"📌 **Predicted next-day prices for {ticker}:**"]
        for name, price in predictions.items():
            chg = ((price - current_price) / current_price) * 100
            arrow = '▲' if chg > 0 else '▼'
            lines.append(f"  • {name}: ₹{price:.2f}  ({arrow} {abs(chg):.2f}%)")
        return '\n'.join(lines)

    # ── RSI Info ─────────────────────────────────────────────────────
    if 'rsi' in txt:
        if rsi_value < 30:
            rsi_msg = "📉 **Oversold** — RSI below 30 suggests the stock may be undervalued and could bounce back."
        elif rsi_value > 70:
            rsi_msg = "📈 **Overbought** — RSI above 70 suggests the stock may be overvalued; momentum could slow."
        else:
            rsi_msg = "➡️ **Neutral zone** — RSI is between 30–70, no extreme signal."
        return f"Current RSI for {ticker}: **{rsi_value:.1f}**\n{rsi_msg}"

    # ── Sentiment ────────────────────────────────────────────────────
    if any(w in txt for w in ['news', 'sentiment', 'opinion', 'market feel']):
        emoji = {'Positive': '😊', 'Negative': '😟', 'Neutral': '😐'}
        return (f"📰 **News Sentiment for {ticker}:** "
                f"{emoji.get(sentiment_label, '😐')} {sentiment_label}\n"
                f"Based on recent headlines analysed with VADER NLP.")

    # ── Buy / Sell / Hold ─────────────────────────────────────────────
    if any(w in txt for w in ['buy', 'sell', 'hold', 'invest', 'advice', 'should i']):
        # Average prediction
        avg_pred = sum(predictions.values()) / len(predictions)
        chg_pct  = ((avg_pred - current_price) / current_price) * 100

        # Score: price direction, RSI, sentiment
        score = 0
        signals = []

        if chg_pct > 2:
            score += 2; signals.append(f"✅ Models predict +{chg_pct:.1f}% price rise")
        elif chg_pct > 0:
            score += 1; signals.append(f"✅ Models predict small rise (+{chg_pct:.1f}%)")
        elif chg_pct < -2:
            score -= 2; signals.append(f"❌ Models predict {chg_pct:.1f}% price drop")
        else:
            signals.append(f"⚠️ Models predict flat movement ({chg_pct:.1f}%)")

        if rsi_value < 35:
            score += 1; signals.append("✅ RSI oversold — potential buy zone")
        elif rsi_value > 65:
            score -= 1; signals.append("⚠️ RSI overbought — caution advised")
        else:
            signals.append("➡️ RSI neutral")

        if sentiment_label == 'Positive':
            score += 1; signals.append("✅ News sentiment positive")
        elif sentiment_label == 'Negative':
            score -= 1; signals.append("❌ News sentiment negative")
        else:
            signals.append("➡️ News sentiment neutral")

        if score >= 3:
            verdict = "🚀 **STRONG BUY**"
        elif score >= 1:
            verdict = "📈 **BUY**"
        elif score == 0:
            verdict = "⚠️ **HOLD**"
        elif score == -1:
            verdict = "📉 **WEAK SELL**"
        else:
            verdict = "❌ **SELL**"

        return (f"**{ticker} Analysis — {verdict}**\n\n" +
                '\n'.join(signals) +
                f"\n\n*Signal score: {score}/4*\n"
                "⚠️ Educational only. Not financial advice.")

    # ── Model accuracy ────────────────────────────────────────────────
    if any(w in txt for w in ['accuracy', 'model', 'rmse', 'r2', 'performance']):
        lines = ["📊 **Model Performance Metrics:**"]
        for name, m in model_results.items():
            lines.append(
                f"  • **{name}**: RMSE ₹{m['RMSE']} | MAE ₹{m['MAE']} "
                f"| R² {m['R²']} | Dir Acc {m['Dir Acc']}%"
            )
        return '\n'.join(lines)

    # ── Help ──────────────────────────────────────────────────────────
    return ("🤖 **StockBot can answer:**\n"
            "- `price` / `predict` — next-day price forecast\n"
            "- `buy` / `sell` / `hold` / `advice` — multi-signal recommendation\n"
            "- `rsi` — RSI indicator analysis\n"
            "- `news` / `sentiment` — news mood analysis\n"
            "- `accuracy` / `model` — model performance metrics")