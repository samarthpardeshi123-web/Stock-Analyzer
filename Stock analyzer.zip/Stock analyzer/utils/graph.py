import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st


def plot_advanced_chart(df, stock_name):
    """
    4-panel interactive chart:
      Row 1 (large) : Candlestick + MA10/MA20/MA50 + Bollinger Bands
      Row 2         : Volume bars
      Row 3         : RSI with overbought/oversold lines
      Row 4         : MACD histogram + signal line
    """
    fig = make_subplots(
        rows=4, cols=1,
        shared_xaxes=True,
        row_heights=[0.50, 0.15, 0.18, 0.17],
        vertical_spacing=0.03,
        subplot_titles=(
            f'{stock_name} — Price & Indicators',
            'Volume',
            'RSI (14)',
            'MACD'
        )
    )

    # ── Row 1: Candlestick ──────────────────────────────────────────
    fig.add_trace(go.Candlestick(
        x=df['Date'],
        open=df['Open'], high=df['High'],
        low=df['Low'],   close=df['Close'],
        name='Price',
        increasing_line_color='#26a69a',
        decreasing_line_color='#ef5350',
        showlegend=False,
    ), row=1, col=1)

    # Bollinger Bands (fill between)
    fig.add_trace(go.Scatter(
        x=df['Date'], y=df['BB_Upper'],
        line=dict(color='rgba(100,149,237,0.3)', width=1),
        name='BB Upper', showlegend=False
    ), row=1, col=1)
    fig.add_trace(go.Scatter(
        x=df['Date'], y=df['BB_Lower'],
        line=dict(color='rgba(100,149,237,0.3)', width=1),
        fill='tonexty',
        fillcolor='rgba(100,149,237,0.07)',
        name='Bollinger Bands'
    ), row=1, col=1)

    # Moving Averages
    for ma, color in [('MA10', '#ff9800'), ('MA20', '#9c27b0'), ('MA50', '#2196f3')]:
        fig.add_trace(go.Scatter(
            x=df['Date'], y=df[ma],
            line=dict(color=color, width=1.2),
            name=ma
        ), row=1, col=1)

    # ── Row 2: Volume ───────────────────────────────────────────────
    colors = ['#26a69a' if c >= o else '#ef5350'
              for c, o in zip(df['Close'], df['Open'])]
    fig.add_trace(go.Bar(
        x=df['Date'], y=df['Volume'],
        marker_color=colors,
        name='Volume', showlegend=False
    ), row=2, col=1)

    # Volume MA
    fig.add_trace(go.Scatter(
        x=df['Date'], y=df['Volume_MA'],
        line=dict(color='#ff9800', width=1),
        name='Vol MA10', showlegend=False
    ), row=2, col=1)

    # ── Row 3: RSI ──────────────────────────────────────────────────
    fig.add_trace(go.Scatter(
        x=df['Date'], y=df['RSI'],
        line=dict(color='#ab47bc', width=1.5),
        name='RSI', showlegend=False
    ), row=3, col=1)

    for level, color, dash in [(70, '#ef5350', 'dash'), (30, '#26a69a', 'dash'), (50, '#888', 'dot')]:
        fig.add_hline(y=level, line_dash=dash, line_color=color,
                      line_width=0.8, row=3, col=1)

    # ── Row 4: MACD ─────────────────────────────────────────────────
    hist_colors = ['#26a69a' if v >= 0 else '#ef5350' for v in df['MACD_Hist']]
    fig.add_trace(go.Bar(
        x=df['Date'], y=df['MACD_Hist'],
        marker_color=hist_colors,
        name='MACD Histogram', showlegend=False
    ), row=4, col=1)
    fig.add_trace(go.Scatter(
        x=df['Date'], y=df['MACD'],
        line=dict(color='#2196f3', width=1.2),
        name='MACD'
    ), row=4, col=1)
    fig.add_trace(go.Scatter(
        x=df['Date'], y=df['MACD_Signal'],
        line=dict(color='#ff9800', width=1.2, dash='dot'),
        name='Signal'
    ), row=4, col=1)

    # ── Layout ──────────────────────────────────────────────────────
    fig.update_layout(
        height=720,
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(size=11),
        legend=dict(orientation='h', yanchor='bottom', y=1.01, xanchor='left', x=0),
        xaxis_rangeslider_visible=False,
        margin=dict(l=50, r=20, t=40, b=20),
    )
    fig.update_yaxes(gridcolor='rgba(128,128,128,0.15)', showgrid=True)
    fig.update_xaxes(gridcolor='rgba(128,128,128,0.1)', showgrid=False)

    st.plotly_chart(fig, use_container_width=True)