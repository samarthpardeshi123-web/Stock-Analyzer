import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

FEATURE_COLS = ['Close', 'MA10', 'MA20', 'MA50', 'RSI',
                'MACD', 'BB_Width', 'Volume_Ratio', 'Volatility']


def train_models(df):
    df = df.copy()
    df['Target'] = df['Close'].shift(-1)
    df = df.dropna()

    X = df[FEATURE_COLS]
    y = df['Target']

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, shuffle=False
    )

    models = {
        'Linear Regression': LinearRegression(),
        'Random Forest':     RandomForestRegressor(n_estimators=100, random_state=42),
        'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, random_state=42),
    }

    results = {}
    trained = {}

    for name, model in models.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)

        rmse = np.sqrt(mean_squared_error(y_test, preds))
        mae  = mean_absolute_error(y_test, preds)
        r2   = r2_score(y_test, preds)

        # Directional accuracy
        actual_dir  = np.sign(y_test.values - X_test['Close'].values)
        pred_dir    = np.sign(preds - X_test['Close'].values)
        dir_acc     = np.mean(actual_dir == pred_dir) * 100

        results[name] = {
            'RMSE':   round(rmse, 2),
            'MAE':    round(mae, 2),
            'R²':     round(r2, 4),
            'Dir Acc': round(dir_acc, 1),
        }
        trained[name] = model

    return trained, results


def predict_price(models, df):
    last_row = df[FEATURE_COLS].iloc[-1].values.reshape(1, -1)
    predictions = {name: float(model.predict(last_row)[0])
                   for name, model in models.items()}
    return predictions
