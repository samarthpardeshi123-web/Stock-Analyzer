import yfinance as yf
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

_analyzer = SentimentIntensityAnalyzer()


def fetch_news(ticker):
    """Fetch recent news headlines using yfinance (no scraping needed)."""
    try:
        t = yf.Ticker(ticker)
        news = t.news or []
        headlines = []
        for item in news[:8]:
            content = item.get('content', {})
            title = content.get('title', '') if isinstance(content, dict) else ''
            if not title:
                title = item.get('title', '')
            if title:
                headlines.append(title)
        return headlines
    except Exception:
        return []


def get_sentiment(ticker):
    """
    Returns:
        headlines : list of str
        scores    : list of float  (compound per headline)
        avg_score : float          (-1 to +1)
        label     : str            (Positive / Neutral / Negative)
    """
    headlines = fetch_news(ticker)

    if not headlines:
        return [], [], 0.0, 'Neutral'

    scores = [_analyzer.polarity_scores(h)['compound'] for h in headlines]
    avg   = sum(scores) / len(scores)

    if avg >= 0.05:
        label = 'Positive'
    elif avg <= -0.05:
        label = 'Negative'
    else:
        label = 'Neutral'

    return headlines, scores, round(avg, 4), label
