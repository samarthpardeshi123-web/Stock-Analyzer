import yfinance as yf

nifty50 = {
    "RELIANCE.NS":   "Reliance Industries",
    "TCS.NS":        "TCS",
    "INFY.NS":       "Infosys",
    "HDFCBANK.NS":   "HDFC Bank",
    "ICICIBANK.NS":  "ICICI Bank",
    "KOTAKBANK.NS":  "Kotak Mahindra Bank",
    "SBIN.NS":       "State Bank of India",
    "ITC.NS":        "ITC Limited",
    "LT.NS":         "Larsen & Toubro",
    "BHARTIARTL.NS": "Bharti Airtel",
    "ASIANPAINT.NS": "Asian Paints",
    "HINDUNILVR.NS": "Hindustan Unilever",
    "MARUTI.NS":     "Maruti Suzuki",
    "TITAN.NS":      "Titan Company",
    "SUNPHARMA.NS":  "Sun Pharma",
    "ULTRACEMCO.NS": "UltraTech Cement",
    "WIPRO.NS":      "Wipro",
    "ADANIENT.NS":   "Adani Enterprises",
    "ADANIPORTS.NS": "Adani Ports",
    "HCLTECH.NS":    "HCL Tech",
    "DIVISLAB.NS":   "Divi's Labs",
    "POWERGRID.NS":  "Power Grid",
    "COALINDIA.NS":  "Coal India",
    "ONGC.NS":       "ONGC",
    "NTPC.NS":       "NTPC",
    "HEROMOTOCO.NS": "Hero MotoCorp",
    "BRITANNIA.NS":  "Britannia",
    "NESTLEIND.NS":  "Nestle",
    "JSWSTEEL.NS":   "JSW Steel",
    "TATASTEEL.NS":  "Tata Steel",
    "GRASIM.NS":     "Grasim",
    "BPCL.NS":       "BPCL",
    "AXISBANK.NS":   "Axis Bank",
    "EICHERMOT.NS":  "Eicher Motors",
    "DRREDDY.NS":    "Dr Reddy",
    "BAJAJFINSV.NS": "Bajaj Finserv",
    "BAJFINANCE.NS": "Bajaj Finance",
    "SBILIFE.NS":    "SBI Life",
    "HDFCLIFE.NS":   "HDFC Life",
    "TECHM.NS":      "Tech Mahindra",
    "UPL.NS":        "UPL",
}

# Sector mapping for portfolio page
nifty50_sectors = {
    "RELIANCE.NS":   "Energy",
    "TCS.NS":        "IT",
    "INFY.NS":       "IT",
    "HDFCBANK.NS":   "Banking",
    "ICICIBANK.NS":  "Banking",
    "KOTAKBANK.NS":  "Banking",
    "SBIN.NS":       "Banking",
    "ITC.NS":        "FMCG",
    "LT.NS":         "Infrastructure",
    "BHARTIARTL.NS": "Telecom",
    "ASIANPAINT.NS": "Consumer",
    "HINDUNILVR.NS": "FMCG",
    "MARUTI.NS":     "Auto",
    "TITAN.NS":      "Consumer",
    "SUNPHARMA.NS":  "Pharma",
    "ULTRACEMCO.NS": "Cement",
    "WIPRO.NS":      "IT",
    "ADANIENT.NS":   "Conglomerate",
    "ADANIPORTS.NS": "Infrastructure",
    "HCLTECH.NS":    "IT",
    "DIVISLAB.NS":   "Pharma",
    "POWERGRID.NS":  "Utilities",
    "COALINDIA.NS":  "Energy",
    "ONGC.NS":       "Energy",
    "NTPC.NS":       "Utilities",
    "HEROMOTOCO.NS": "Auto",
    "BRITANNIA.NS":  "FMCG",
    "NESTLEIND.NS":  "FMCG",
    "JSWSTEEL.NS":   "Metals",
    "TATASTEEL.NS":  "Metals",
    "GRASIM.NS":     "Cement",
    "BPCL.NS":       "Energy",
    "AXISBANK.NS":   "Banking",
    "EICHERMOT.NS":  "Auto",
    "DRREDDY.NS":    "Pharma",
    "BAJAJFINSV.NS": "Finance",
    "BAJFINANCE.NS": "Finance",
    "SBILIFE.NS":    "Insurance",
    "HDFCLIFE.NS":   "Insurance",
    "TECHM.NS":      "IT",
    "UPL.NS":        "Agri",
}


def get_stock_data(ticker, period="1y"):
    data = yf.download(ticker, period=period, progress=False, auto_adjust=True)
    data.reset_index(inplace=True)
    # Flatten MultiIndex columns if present
    if isinstance(data.columns, type(data.columns)) and hasattr(data.columns, 'levels'):
        data.columns = [col[0] if isinstance(col, tuple) else col for col in data.columns]
    return data


def get_current_price(ticker):
    try:
        t = yf.Ticker(ticker)
        info = t.fast_info
        return float(info.last_price)
    except Exception:
        data = get_stock_data(ticker, period="5d")
        return float(data["Close"].values[-1])